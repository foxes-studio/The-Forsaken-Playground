var searchData=
[
  ['main_2ec',['main.c',['../main_8c.html',1,'']]],
  ['minute1',['minute1',['../structtemps.html#a400cb69ff8af9b43eb6abab78fa0161c',1,'temps']]],
  ['minute2',['minute2',['../structtemps.html#a2414045fced292cf676b7fd59ec9181c',1,'temps']]]
];
