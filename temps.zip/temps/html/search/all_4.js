var searchData=
[
  ['police',['police',['../structtemps.html#a5496aa7ef92a402878dfa83dc44cb570',1,'temps']]],
  ['position_5ftemp',['position_temp',['../structtemps.html#a77d09ab78c81ed3951ff41e1974cc14d',1,'temps']]]
];
