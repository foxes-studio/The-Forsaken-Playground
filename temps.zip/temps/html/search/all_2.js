var searchData=
[
  ['inisaliser_5ftemp',['inisaliser_temp',['../temps_8c.html#a8e74d45670becfd4b6a3718ea4a4543d',1,'inisaliser_temp(temps temp):&#160;temps.c'],['../temps_8h.html#a8e74d45670becfd4b6a3718ea4a4543d',1,'inisaliser_temp(temps temp):&#160;temps.c']]]
];
