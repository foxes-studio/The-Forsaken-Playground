var searchData=
[
  ['heur1',['heur1',['../structtemps.html#a2011835f5e7a49a1233eda77a44dd2e5',1,'temps']]],
  ['heur2',['heur2',['../structtemps.html#a54b7d1185a09a8fb91dba7e6509bcd15',1,'temps']]]
];
