var searchData=
[
  ['collisionbb',['collisionbb',['../vie_8c.html#a7ebe6513ea3048519d01726d54a128c0',1,'collisionbb(SDL_Rect posj, SDL_Rect posobj):&#160;vie.c'],['../vie_8h.html#a7ebe6513ea3048519d01726d54a128c0',1,'collisionbb(SDL_Rect posj, SDL_Rect posobj):&#160;vie.c']]]
];
