var searchData=
[
  ['affichageobj',['affichageObj',['../obj_8c.html#a33ac93d4cbcb8ad19cce6f86dde40ade',1,'affichageObj(Objet obj, SDL_Surface *screen):&#160;obj.c'],['../obj_8h.html#a33ac93d4cbcb8ad19cce6f86dde40ade',1,'affichageObj(Objet obj, SDL_Surface *screen):&#160;obj.c']]],
  ['affichervie',['affichervie',['../vie_8c.html#a4e8a988f213b277d1d87e0e595fdfd31',1,'affichervie(vie *vie, SDL_Rect *posj, SDL_Rect posobj, SDL_Surface *ecran, int *i):&#160;vie.c'],['../vie_8h.html#a4e8a988f213b277d1d87e0e595fdfd31',1,'affichervie(vie *vie, SDL_Rect *posj, SDL_Rect posobj, SDL_Surface *ecran, int *i):&#160;vie.c']]]
];
