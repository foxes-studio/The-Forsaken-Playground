var searchData=
[
  ['init_5fscore',['init_score',['../score_8c.html#a054bc40f63fa60038aca3a9ec4a1ccfa',1,'init_score(score *s):&#160;score.c'],['../score_8h.html#a054bc40f63fa60038aca3a9ec4a1ccfa',1,'init_score(score *s):&#160;score.c']]]
];
