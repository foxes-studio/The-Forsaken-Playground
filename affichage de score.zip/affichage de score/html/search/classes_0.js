var searchData=
[
  ['score',['score',['../structscore.html',1,'']]]
];
