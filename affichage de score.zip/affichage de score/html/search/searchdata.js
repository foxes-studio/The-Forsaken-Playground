var indexSectionsWithContent =
{
  0: "afimps",
  1: "s",
  2: "ms",
  3: "aim",
  4: "fp",
  5: "s"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs"
};

