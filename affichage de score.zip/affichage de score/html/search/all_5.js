var searchData=
[
  ['score',['score',['../structscore.html',1,'score'],['../score_8h.html#a1240ca29fa6f99334b17271ea026bc91',1,'score():&#160;score.h']]],
  ['score_2ec',['score.c',['../score_8c.html',1,'']]],
  ['score_2eh',['score.h',['../score_8h.html',1,'']]]
];
