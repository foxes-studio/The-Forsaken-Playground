var searchData=
[
  ['afficherscore',['afficherscore',['../score_8c.html#a1ea27484e6c76a57ad6efb2a083329f2',1,'afficherscore(score *s, SDL_Surface *screen, int *run):&#160;score.c'],['../score_8h.html#a1ea27484e6c76a57ad6efb2a083329f2',1,'afficherscore(score *s, SDL_Surface *screen, int *run):&#160;score.c']]]
];
