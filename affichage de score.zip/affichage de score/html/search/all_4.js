var searchData=
[
  ['ps',['ps',['../structscore.html#af7e01271c42cd5fae81f5cc78f1b8c3e',1,'score']]]
];
