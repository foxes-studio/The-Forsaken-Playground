var searchData=
[
  ['afficher_5fresultat',['afficher_resultat',['../enig_8h.html#a4000acf4af9607e9d50a33b70643a99a',1,'afficher_resultat(SDL_Surface *screen, int s, int r, enigme *en):&#160;enigf.c'],['../enigf_8c.html#a4000acf4af9607e9d50a33b70643a99a',1,'afficher_resultat(SDL_Surface *screen, int s, int r, enigme *en):&#160;enigf.c']]]
];
