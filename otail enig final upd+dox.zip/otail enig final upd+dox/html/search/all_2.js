var searchData=
[
  ['generate_5fafficher',['generate_afficher',['../enig_8h.html#a345b17b765ec6a985fb162957d6e900c',1,'generate_afficher(SDL_Surface *screen, char image [], enigme *e, int *alea):&#160;enigf.c'],['../enigf_8c.html#a345b17b765ec6a985fb162957d6e900c',1,'generate_afficher(SDL_Surface *screen, char image [], enigme *e, int *alea):&#160;enigf.c']]]
];
