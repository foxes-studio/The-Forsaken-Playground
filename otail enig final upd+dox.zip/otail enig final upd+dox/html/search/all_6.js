var searchData=
[
  ['resolution',['resolution',['../enigf_8c.html#ae855a03b9d7f7619bac3843306965df9',1,'enigf.c']]]
];
