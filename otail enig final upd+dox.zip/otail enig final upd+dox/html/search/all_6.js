var searchData=
[
  ['resolution',['resolution',['../enig_8h.html#ae855a03b9d7f7619bac3843306965df9',1,'resolution(int *running, int *run):&#160;enigf.c'],['../enigf_8c.html#ae855a03b9d7f7619bac3843306965df9',1,'resolution(int *running, int *run):&#160;enigf.c']]]
];
