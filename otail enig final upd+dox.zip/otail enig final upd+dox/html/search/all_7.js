var searchData=
[
  ['solution_5fe',['solution_e',['../enigf_8c.html#a35379216444e495869c21407672218a2',1,'enigf.c']]]
];
