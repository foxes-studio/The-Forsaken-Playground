var searchData=
[
  ['solution_5fe',['solution_e',['../enig_8h.html#a35379216444e495869c21407672218a2',1,'solution_e(char image []):&#160;enigf.c'],['../enigf_8c.html#a35379216444e495869c21407672218a2',1,'solution_e(char image []):&#160;enigf.c']]]
];
