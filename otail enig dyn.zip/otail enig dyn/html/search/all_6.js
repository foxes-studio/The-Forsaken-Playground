var searchData=
[
  ['resolution1',['resolution1',['../enigme_8c.html#a358bc14bd82f78e19812f086399c72e5',1,'enigme.c']]]
];
