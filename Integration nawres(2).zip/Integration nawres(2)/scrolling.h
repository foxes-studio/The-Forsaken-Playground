#ifndef JEU_H_INCLUDED
#define JEU_H_INCLUDED
#include <SDL/SDL.h>


SDL_Rect scroll1(SDL_Surface *ecran,SDL_Surface *imageDeFond ,int continuer ,SDL_Rect positionFond) ; 
#endif // JEU_H_INCLUDED
